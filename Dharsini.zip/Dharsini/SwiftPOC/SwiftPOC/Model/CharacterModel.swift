//
//  CharacterModel.swift
//  SwiftPOC
//
//  Created by user on 28/01/26.
//

import Foundation

struct CharacterModel : Codable,Identifiable,Hashable{
    var id : Int { _id }
    let _id : Int
    let films : [String]
    let shortFilms : [String]
    let tvShows : [String]
    let videoGames : [String]
    let parkAttractions : [String]
    let allies : [String]
    let enemies : [String]
    let name : String
    let imageURL : URL?
    let url : URL?
    
    enum codingKeys : String,CodingKey{
        case id
        case films
        case shortFilms
        case tvShows
        case videoGames
        case parkAttractions
        case allies
        case enemies
        case name
        case imageURL
        case url
        
        
    }
    func matches(query : String) -> Bool{
        guard !query.isEmpty else {return true}
        let q = query.folding(options: .diacriticInsensitive, locale: .current)
            .lowercased()
        if name.lowercased().contains(q) {return true}
        
        if films.contains(where: {$0.lowercased().contains(q)}) {return true}
        
        return false
    }
}

struct CharacterInfo : Codable,Hashable{
    let count : Int
    let totalPages : Int
    let previousPage : URL?
    let nextPage : URL?
}

struct CharacterResponse : Codable,Hashable{
    let data : [CharacterModel]
    let info : CharacterInfo
    
   
    }



