//
//  FoodImageModel.swift
//  SwiftPOC
//
//  Created by user on 06/02/26.
//
import Foundation

struct FoodImageModel : Codable,Identifiable{
    let id = UUID()
    let image : String
    var name : String{
        guard let url = URL(string: image) else { return "Food" }
        let parts = url.pathComponents
        if let imageIndex = parts.firstIndex(of: "images"), parts.count > imageIndex + 1{
            return beautify(parts[imageIndex + 1])
        }
            return "Food"
    }
    
    private func beautify(_ raw : String)-> String{
        raw.replacingOccurrences(of: "-", with: " ")
            .replacingOccurrences(of: "_", with: " ")
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .capitalized
    }
}
