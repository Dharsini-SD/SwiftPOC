//
//  FoodItemModel.swift
//  SwiftPOC
//
//  Created by user on 22/01/26.
//

import Foundation

struct FoodItemModel : Codable,Hashable,Identifiable{
    let id : UUID
    let imageURL : String
    let name : String
   // let category : String
    let price : Double
    let rating : Double
}

struct FoodImageResponse : Codable{
    let image : String
}
