//
//  ReviewModel.swift
//  SwiftPOC
//
//  Created by user on 27/01/26.
//

import Foundation
import SwiftUI

struct ReviewModel : Codable,Identifiable,Hashable{
    let id : String
    let product : String
    let manufacturer : String
    let category : String
    let videoTitle : String
    let videoCode : String
    let dateReleased : String
    let rating :Double
    
    var releasedDate : Date{
        let formatter = DateFormatter()
        formatter.dateFormat = "dd-mm-yyyy"
        formatter.timeZone = TimeZone(secondsFromGMT: 0)
        //formatter.date(from: dateReleased)
        return formatter.date(from: dateReleased) ?? Date()
    }
    
    func matches(query : String) -> Bool{
        guard !query.isEmpty else {return true}
        let q = query.folding(options: .diacriticInsensitive, locale: .current)
                .lowercased()
        return product.lowercased().contains(q)
        || manufacturer.lowercased().contains(q)
        || category.lowercased().contains(q)
        || videoCode.lowercased().contains(q)
        || videoTitle.lowercased().contains(q)
    }
}
