//
//  FoodApiService.swift
//  SwiftPOC
//
//  Created by user on 22/01/26.
//

import Foundation



final class FoodAPIService{
    static let shared : FoodAPIService = FoodAPIService()
    private init(){}
    
    func fetchFoodImage()async throws -> String{
        let url = URL(string: "https://foodish-api.com/api/")!
        let (data,_) = try await URLSession.shared.data(from: url)
        let response = try JSONDecoder().decode(FoodImageResponse.self, from: data)
        print(response.image)
        return response.image
        
    }
}
