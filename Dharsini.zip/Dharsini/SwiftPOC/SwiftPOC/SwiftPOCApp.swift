//
//  SwiftPOCApp.swift
//  SwiftPOC
//
//  Created by user on 22/01/26.
//

import SwiftUI

@main
struct SwiftPOCApp: App {
    var body: some Scene {
        WindowGroup {
            RootView()
        }
    }
}
