//
//  LoginView.swift
//  SwiftPOC
//
//  Created by user on 22/01/26.
//

import SwiftUI

struct LoginView: View {
    @StateObject var loginVM : LoginViewModel = LoginViewModel()
    @AppStorage("isLoggedin") private var isLoggedIn : Bool = false
    @State private var isError : Bool = false
    @State private var isRegisterSheet : Bool = false
    var body: some View {
        VStack{
            Text("Welcome to Food Court")
                .font(.largeTitle)
                .fontWeight(.bold)
                //.foregroundStyle(Color.yellow)
                .padding(.bottom,40)
            
            VStack(spacing: 16){
                
                HStack{
                    Image(systemName: "person.fill")
                        .foregroundStyle(Color.gray)
                        .frame(width: 20)
                        
                    TextField("Username",text: $loginVM.userName)
                }
                .padding(.horizontal)
                .frame(height: 50)
                .background{
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(Color.gray,lineWidth:1)
                        
                }
                
                
                HStack{
                    Image(systemName: "lock.fill")
                        .foregroundStyle(Color.gray)
                        .frame(width:20)
                        
                    SecureField("Password",text: $loginVM.password)
                }
                .padding(.horizontal)
                .frame(height:50)
                .background{
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(Color.gray,lineWidth:1)
                }
                
                               
                
                if isError {
                    Text("Invalid username/password")
                        .foregroundStyle(Color.red)
                        .font(.footnote)
                        .padding(.top)
                }
                
                Button(action:{
                    if loginVM.userName.isEmpty || loginVM.password.isEmpty {
                        isError = true
                    }else{
                        isLoggedIn = true
                    }
                }){
                    Text("Login")
                        .foregroundStyle(Color.black)
                }.frame(maxWidth: .infinity)
                    .padding()
                    .background(.yellow)
                    .cornerRadius(15)
                    
            }.padding(20)
                .background(
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(Color.black.opacity(0.4),lineWidth: 2)
                     //.padding()
                )
                .padding(.horizontal)
                .shadow(radius: 10)
                
            
            Button(action: {
                
            }){
                Text("Forget Password?").foregroundStyle(.black)
            }.padding()
            
            Button(action: {
                isRegisterSheet = true
            }){
                Text("Don't have an account? Register!").foregroundStyle(.black)
            }.padding()
            
            
        }
        .frame(maxWidth:.infinity,maxHeight: .infinity)
        .edgesIgnoringSafeArea(.all)
        .background(
            LinearGradient(colors: [.accentColor.opacity(0.6),.white], startPoint: .topLeading, endPoint: .bottomTrailing)
        )
        .sheet(isPresented: $isRegisterSheet){
            SignUpView()
        }
    }
}

struct TextFieldModifier : ViewModifier{
    func body(content: Content) -> some View {
        content
            .padding()
            .background(Color.gray.opacity(0.3))
            .cornerRadius(15)
            .padding(.horizontal)
    }
}

#Preview {
    LoginView()
}
