//
//  SignUpView.swift
//  SwiftPOC
//
//  Created by user on 22/01/26.
//

import SwiftUI

struct SignUpView: View {
   // @State var name : String = ""
   // @State var password : String = ""
   // @State var phoneNumber : String = ""
   // @State var mailAddress : String = ""
    
    @StateObject var signupVM : SignUpViewModel = SignUpViewModel()
    @Environment(\.dismiss) var dismiss
    @State private var user : [String:Any] = [:]
    var body: some View {
        NavigationStack{
            VStack{
                TextField("Name", text: $signupVM.userName)
                    .modifier(TextFieldModifier())
                    .padding(.vertical,5)
                
                SecureField("Password",text:$signupVM.password)
                    .modifier(TextFieldModifier())
                    .padding(.vertical,5)
                
                TextField("MailAddress", text: $signupVM.mail)
                    .modifier(TextFieldModifier())
                    .padding(.vertical,5)
                
                TextField("PhoneNumber", text: $signupVM.phone)
                    .modifier(TextFieldModifier())
                    .padding(.vertical,5)
                    .keyboardType(.numberPad)
                
                HStack{
                    Button(action:{
                      
                        user["Name"] = signupVM.userName
                        user["Password"] = signupVM.password
                        user["Mail"] = signupVM.mail
                        user["Phone"] = signupVM.phone
                                                                      
                        
                        UserDefaults.standard.set(user, forKey: "User")
                        dismiss()
                    }){
                        Text("Register").foregroundStyle(Color.black)
                    }.padding(.top)
                        .buttonStyle(.borderedProminent)
                    
                    Button(action:{
                        dismiss()
                    }){
                        Text("Cancel").foregroundStyle(Color.black)
                    }.padding(.top)
                        .buttonStyle(.borderedProminent)
                   
                }
                
                
                
            }.navigationTitle("Register")
                .frame(maxWidth:.infinity,maxHeight: .infinity)
                .edgesIgnoringSafeArea(.all)
                .background(
                    LinearGradient(colors: [.accentColor.opacity(0.6),.white], startPoint: .topLeading, endPoint: .bottomTrailing)
                )
        }
    }
}

#Preview {
    SignUpView()
}
