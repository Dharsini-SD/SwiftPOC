//
//  RootView.swift
//  SwiftPOC
//
//  Created by user on 22/01/26.
//

import Foundation
import SwiftUI

struct RootView : View {
    @AppStorage("isLoggedin") private var isLoggedIn : Bool = false
    var body: some View {
        NavigationStack{
            if isLoggedIn{
                TabsView()
            }else{
                LoginView()
            }
        }
        
    }
}
