//
//  TabView.swift
//  SwiftPOC
//
//  Created by user on 23/01/26.
//

import SwiftUI


struct TabsView: View {
    var body: some View {
        TabView{
            ShopView()
                .tabItem{
                    Image(systemName: "cart.fill")
                }
            MultiGridView()
                .tabItem{
                    Image(systemName: "house.fill")
                }
            FilterView()
                .tabItem{
                    Image(systemName: "line.horizontal.3.decrease")
                }
            
            TableView()
                .tabItem{
                    Image(systemName: "doc.text.fill")
                }
            
            MenuView()
                .tabItem{
                    Image(systemName: "line.3.horizontal")
                }
            
        }
    }
}


