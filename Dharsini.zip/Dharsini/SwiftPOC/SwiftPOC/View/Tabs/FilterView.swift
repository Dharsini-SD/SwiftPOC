//
//  FilterView.swift
//  SwiftPOC
//
//  Created by user on 28/01/26.
//

import SwiftUI

struct FilterView: View {
    @StateObject var characterVM : CharacterViewModel = CharacterViewModel()
                               
    var body: some View {
        NavigationView{
           // ScrollView{
                VStack{
                    if characterVM.isLoading{
                        ProgressView()
                            .frame(maxWidth: .infinity,maxHeight: .infinity)
                        
                    }else{
                     List{
                        ForEach(characterVM.reviewList,id:\.id){item in
                            HStack(spacing:12){
                                if let imgUrl = item.imageURL {
                                    AsyncImage(url: imgUrl){phase in
                                        switch phase {
                                            case .empty:
                                                placeHolder
                                            case .success(let image):
                                                image.resizable()
                                                    .aspectRatio(contentMode: .fill)
                                                    .frame(width:60,height:60)
                                                    .clipShape(RoundedRectangle(cornerRadius: 10))
                                            case .failure(let error):
                                                placeHolder
                                            
                                            default:
                                                placeHolder
                                        }
                                    }
                                }
                                
                                VStack(alignment: .leading, spacing:4){
                                    Text(item.name)
                                        .font(.headline)
                                    
                                    Text(item.films.joined(separator: ","))
                                        .font(.subheadline)
                                        .lineLimit(1)
                                    
                                }
                                
                            }.frame(alignment: .leading)
                        }
                     }
                    }
             //   }
            }.navigationTitle("Disney Characters")
            //.navigationTitle("Disney Characters")
            .toolbar{
                ToolbarItem(placement: .navigationBarTrailing){
                    Button{
                        characterVM.reset()
                    }label:{
                        Label("Reset", systemImage:  "arrow.counterclockwise")
                        
                    }
                }
            }
            .searchable(text: $characterVM.searchText,placement: .navigationBarDrawer(displayMode: .automatic),prompt: "Search by Name")
            .refreshable {
                characterVM.refresh()
            }
            .task {
                characterVM.load()
            }
            
        }
        
        
    }
    
    private var placeHolder : some View{
        ZStack{
            RoundedRectangle(cornerRadius: 10)
                .fill(Color.gray.opacity(0.2))
                .frame(width: 60,height: 60)
            Image(systemName: "photo")
                .foregroundStyle(Color.gray)
        }
    }
}

#Preview {
    FilterView()
}
    
