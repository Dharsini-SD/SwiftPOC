//
//  FoodGridView.swift
//  SwiftPOC
//
//  Created by user on 06/02/26.
//

import SwiftUI

struct FoodGridView: View {
    let title : String
    let layout : [GridItem]
    let items : [FoodImageModel]
    
    var body: some View {
        VStack(alignment: .leading){
            Text(title)
                .font(.title2)
                .bold()
                .padding(.horizontal)
            
            LazyVGrid(columns: layout,spacing: 12){
                ForEach(items){item in
                    VStack(alignment: .leading,spacing: 6){
                        FoodCard(item: item)
                    }
                   
                }
            }
            .padding(.horizontal)
        }
        .padding(.vertical,10)
    }
}


