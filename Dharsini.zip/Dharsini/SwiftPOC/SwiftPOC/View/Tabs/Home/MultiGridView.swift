//
//  MultiGridView.swift
//  SwiftPOC
//
//  Created by user on 06/02/26.
//

import SwiftUI

struct MultiGridView: View {
    @StateObject private var foodService = FoodService()
    var body: some View {
        NavigationView{
            ScrollView{
                VStack(spacing: 10){
                    FoodGridView(
                        title: "Fast Delivery",
                        layout: Array(repeating: .init(.flexible()), count: 2),
                        items: foodService.items
                    )
                    
                    FoodGridView(
                        title: "Favourites",
                        layout: Array(repeating: .init(.flexible()), count: 3),
                        items: foodService.items
                    )
                    
                    FoodGridView(
                        title: "Explore",
                        layout: [GridItem(.flexible())],
                        items: foodService.items
                    )
                }
            }
            .navigationTitle("Home")
            .onAppear{
                foodService.load(count: 3)
            }
            .searchable(
                text: $foodService.searchText,
                placement: .navigationBarDrawer(displayMode: .automatic),
                prompt: "Search by name"
            )
            .onChange(of: foodService.searchText){newValue in
                if newValue.isEmpty{
                    foodService.resetSearch()
                }
            }
                      
            .toolbar{
                if !foodService.searchText.isEmpty{
                    ToolbarItem(placement: .navigationBarTrailing){
                        Button{
                            foodService.resetSearch()
                        }label:{
                            Label("Reset", systemImage: "arrow.counterclockwise")
                        }
                    }
                }
                    
            }        }
        
    }
}

#Preview {
    MultiGridView()
}
