//
//  MenuView.swift
//  SwiftPOC
//
//  Created by user on 30/01/26.
//

import Foundation
import SwiftUI
import WebKit
import CoreLocation

struct MenuView : View {
    @AppStorage("isLoggedin") private var isLoggedIn : Bool = false
    @State private var locationEnabled : Bool = false
    @State private var showPrivacy : Bool = false
    var body: some View {
        
        NavigationView{
            List{
                Toggle(isOn: Binding(get: {
                    locationEnabled
                }, set: { value in
                    if value{
                        CLLocationManager().requestWhenInUseAuthorization()
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5){
                            locationEnabled = CLLocationManager.locationServicesEnabled()
                        }
                    }else{
                       // openSettingsAlert()
                    }
                    
                })){
                    Text("Location Permission")
                }
                
                NavigationLink(destination:
                    WebView(url:URL(string: "https://example.com/privacy")!),isActive : $showPrivacy)
                {
                    Text("Privacy & Policy")
                }
                
                
                Button("Contact Us"){
                    contactSheet()
                }
                
                Button(role: .destructive){
                    logout()
                }label: {
                    Text("Logout")
                }
            }
            .navigationTitle("Menu")
            .onAppear{
                locationEnabled = CLLocationManager.locationServicesEnabled()
                
                
            }
        }
    }
    
    func contactSheet(){
        if let url = URL(string: "mailto:support@example.com?support=Support%20Request"){
            UIApplication.shared.open(url)
        }
    }
    
    func logout(){
        isLoggedIn = false
    }
}

struct WebView : UIViewRepresentable{
    let url : URL
    func makeUIView(context: Context) ->WKWebView {WKWebView()}
    func updateUIView(_ uiView:WKWebView,context: Context){
        uiView.load(URLRequest(url: url))
    }
    
}




