//
//  FoodCardView.swift
//  SwiftPOC
//
//  Created by user on 30/01/26.
//

import SwiftUI

struct FoodCardView: View {
    let item : FoodItemModel
    var body: some View {
        VStack{
            AsyncImage(url: URL(string:"\(item.imageURL)" )){image in
                image.resizable()
                //.scaledToFit()
                    .frame(width: 120,height: 140)
                    .scaledToFill()
                    .clipShape(RoundedRectangle(cornerRadius: 8))
            }placeholder:{
                ZStack{
                    RoundedRectangle(cornerRadius:8)
                        .fill(Color.gray.opacity(0.2))
                    
                    ProgressView()
                }.frame(height: 140)
                    .clipShape(RoundedRectangle(cornerRadius: 8))
            }
            .shadow(radius: 3)
            
            HStack{
                Text(item.name.localizedCapitalized)
                    .font(.headline)
                    //.lineLimit(1)
                    .foregroundStyle(Color.black)
                    .frame(alignment: .leading)
                    .padding(.leading,15)
                Spacer()
                Text("\(Int(item.rating)) ⭐")
                    .font(.caption)
                    .foregroundStyle(.black)
                    .font(.headline)
            }.frame(maxWidth: .infinity)
    
     //   Text("Rs: \(Int(item.price))")
        
     //       .font(.subheadline)
     //       .bold()
     //       .foregroundStyle(Color.black)
            
    }
        
    
        .padding()
        .background(Color.yellow.opacity(0.3))
        .cornerRadius(10)
    }
}

