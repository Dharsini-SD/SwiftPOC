//
//  FoodDetailView.swift
//  SwiftPOC
//
//  Created by user on 30/01/26.
//

import SwiftUI

struct FoodDetailView: View {
    let item : FoodItemModel
    @StateObject var vm = FoodDetailViewModel()
    var body: some View {
        ScrollView{
            VStack(alignment: .leading,spacing: 16){
                AsyncImage(url: URL(string:"\(item.imageURL)" )){image in
                    image.resizable()
                        .scaledToFit()
                    
                }placeholder:{
                    ZStack{
                        RoundedRectangle(cornerRadius:8)
                            .fill(Color.gray.opacity(0.2))
                        
                        ProgressView()
                    }
                    .scaledToFit()
                        .clipShape(RoundedRectangle(cornerRadius: 8))
                        .padding(.bottom)
                }
                
                Text(item.name.localizedCapitalized)
                   // .textInputAutocapitalization(.sentences)
                    .font(.largeTitle)
                    .bold()
                Text("Rs : \(Int(item.price))")
                    .font(.headline)
                
                Divider()
                
               // DatePicker("Schedule", selection: $vm.scheduledDate,displayedComponents: .date)
                
                VStack{
                    Text("Spice Level :   \(Int(vm.spiceLevel))").frame(maxWidth: .infinity,alignment: .leading)
                    Slider(value: $vm.spiceLevel,in: 0...10)
                }
                
                Stepper("Quantity : \(vm.quantity)", value: $vm.quantity,in: 0...10 )
                
              
                
                Spacer()
                
                
            }
            .padding()
        }
        .navigationTitle("\(item.name.localizedCapitalized)")
        .navigationBarTitleDisplayMode(.inline)
    }
}


