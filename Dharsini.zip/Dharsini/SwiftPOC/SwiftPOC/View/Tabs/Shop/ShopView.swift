//
//  ShopView.swift
//  SwiftPOC
//
//  Created by user on 23/01/26.
//

import SwiftUI

struct ShopView: View {
    @StateObject var foodItemsVM : FoodCardViewModel = FoodCardViewModel()
    private let columns = [GridItem(.flexible()),
                           GridItem(.flexible())]
    var body: some View {
        NavigationStack{
            NavigationView{
                
                
                ScrollView{
                    LazyVGrid(columns: columns){
                       // let data = foodItemsVM.filtered
                        ForEach(foodItemsVM.items){item in
                            NavigationLink(value:item){
                                FoodCardView(item: item)
                                    .onAppear{
                                        if item == foodItemsVM.items.last{
                                            foodItemsVM.loadItems()
                                        }
                                    }
                            }
                        }
                        
                    }.padding()
                }.navigationTitle("Food Gallery")
            }
                .navigationBarTitleDisplayMode(.large)
                .navigationDestination(for: FoodItemModel.self){item in
                    FoodDetailView(item: item)
                }
                .searchable(
                    text: $foodItemsVM.searchText,
                    placement: .navigationBarDrawer(displayMode: .automatic),
                    prompt: "Search by name"
                )
                .onChange(of: foodItemsVM.searchText){newValue in
                    if newValue.isEmpty{
                        foodItemsVM.resetSearch()
                    }
                }
                          
                .toolbar{
                    if !foodItemsVM.searchText.isEmpty{
                        ToolbarItem(placement: .navigationBarTrailing){
                            Button{
                                foodItemsVM.resetSearch()
                            }label:{
                                Label("Reset", systemImage: "arrow.counterclockwise")
                            }
                        }
                    }
                        
                }
           
        }
        
        
        .task {
            foodItemsVM.loadInitial()
        }
    }
}

#Preview {
    ShopView()
}
