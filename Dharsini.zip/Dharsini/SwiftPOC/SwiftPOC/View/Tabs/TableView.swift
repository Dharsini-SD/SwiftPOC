//
//  TableView.swift
//  SwiftPOC
//
//  Created by user on 03/02/26.
//

import SwiftUI

struct TableView: View {
    @StateObject var foodItemVm : FoodCardViewModel = FoodCardViewModel()
    var body: some View {
        NavigationView{
            VStack(){
               
                FoodTableHeader()
                Divider()
                List(foodItemVm.items){item in
                    FoodTableRow(item: item)
                        .onAppear{
                            if item == foodItemVm.items.last{
                                foodItemVm.loadItems()
                            }
                    }
                }.listStyle(.plain)
            }.navigationTitle("Food Table")
                .task {
                    foodItemVm.loadInitial()
                    
                }
                
        }
        
    }
    
   
}


struct FoodTableHeader : View {
    var body: some View {
        HStack{
            Text("Food Name")
                .font(.headline)
                .frame(maxWidth: .infinity,alignment: .center)
            
            Text("Rating")
                .font(.headline)
                .frame(maxWidth: .infinity,alignment: .center)
            
            Text("Price")
                .font(.headline)
                .frame(maxWidth: .infinity,alignment: .center)
        }.padding()
            .background(Color.yellow.opacity(0.3))
    }
}


struct FoodTableRow : View{
    let item : FoodItemModel
    var body: some View {
        HStack{
            Text(item.name.localizedCapitalized)
                .frame(maxWidth: .infinity,alignment: .leading)
            
            StarRatingView(rating: Int(item.rating))
                .frame(maxWidth: .infinity,alignment:.center)
            
            Text("\(Int(item.price))")
                .frame(maxWidth: .infinity,alignment: .center)
        }
        .padding(.horizontal)
        .padding(.vertical,8)
    }
}




struct StarRatingView : View {
    let rating : Int
    let max : Int = 5
    
    var body: some View {
        HStack(spacing: 2){
            ForEach(1...max,id: \.self){i in
                Image(systemName: i < rating ? "star.fill":"star")
                    .foregroundStyle(i<rating ? Color.yellow : Color.gray)
            }
        }
        .accessibilityLabel("\(rating) out of \(max) stars")
    }
}
