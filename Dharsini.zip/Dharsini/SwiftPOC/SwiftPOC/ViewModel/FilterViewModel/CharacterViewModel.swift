//
//  CharacterViewModel.swift
//  SwiftPOC
//import SwiftUI
//  Created by user on 28/01/26.
//

import Foundation
import SwiftUI
import Combine
@MainActor
final class CharacterViewModel : ObservableObject{
    @Published var reviewList : [CharacterModel] = []
    @Published var isLoading : Bool = false
    @Published var totalCount : Int = 0
    @Published var searchText : String = ""
    private var reviewFilterList : [CharacterModel] = []
    private var cancellables = Set<AnyCancellable>()
    private let service : CharacterAPIService
    
    init(service:CharacterAPIService = CharacterAPIService.characterAPIService){
        
        self.service = service
        bindSearch()
    }
    func load(){
        Task{
            await MainActor.run{
                isLoading = true
                defer{isLoading = false}
            }
            
            do{
                let res = try await service.getCharacters()
                totalCount = res.count
                
                reviewList = res
                reviewFilterList = res
            }catch{
                print(error.localizedDescription)
                
            }
            
        }
    }
    
    func refresh(){
        reviewFilterList.removeAll()
        load()
    }
    
    func reset(){
        searchText = ""
        reviewFilterList = reviewList
    }
    
    func bindSearch(){
        $searchText
            .removeDuplicates()
            .debounce(for: .milliseconds(100), scheduler: DispatchQueue.main)
            .sink{[weak self] item in
                self?.applyFilter(query: item)
            }
            .store(in: &cancellables)
    }
    
    func applyFilter(query : String) {
        let q = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !q.isEmpty else {
            reviewList = reviewFilterList
            return
        }
        var results = reviewList
        reviewList = reviewFilterList.filter{$0.matches(query : q)}
        
    }
    
}
    

