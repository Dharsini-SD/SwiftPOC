//
//  ReviewViewModel.swift
//  SwiftPOC
//
//  Created by user on 27/01/26.
//

import SwiftUI
import Combine
@MainActor
final class ReviewViewModel : ObservableObject{
    @Published var reviewList : [ReviewModel] = []
    @Published var isLoading : Bool = false
    @Published var totalCount : Int = 0
    @Published var searchText : String = ""
    private var reviewFilterList : [ReviewModel] = []
    private var cancellables = Set<AnyCancellable>()
    private let service : ReviewAPIService
    
    init(service:ReviewAPIService = ReviewAPIService.reviewAPIService){
        self.service = service
        bindSearch()
    }
    
    func load(){
        Task{
            await MainActor.run{
                isLoading = true
                defer{isLoading = false}
            }
            
            do{
                let res = try await service.getReviews()
                totalCount = res.count
                let sortedRes = res.sorted{
                    ($0.releasedDate,$0.rating) > ($1.releasedDate,$1.rating)
                }
                reviewList = sortedRes
                reviewFilterList = sortedRes
            }catch{
                print(error.localizedDescription)
                
            }
            
        }
    }
    
    func refresh(){
        reviewFilterList.removeAll()
        load()
    }
    
    func reset(){
        searchText = ""
        reviewFilterList = reviewList
    }
    
    func bindSearch(){
        $searchText
            .removeDuplicates()
            .debounce(for: .milliseconds(100), scheduler: DispatchQueue.main)
            .sink{[weak self] item in
                self?.applyFilter(query: item)
            }
            .store(in: &cancellables)
    }
    
    func applyFilter(query : String) {
        let q = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !q.isEmpty else {
            reviewList = reviewFilterList
            return
        }
        reviewList = reviewFilterList.filter{ $0.matches(query : q)}
        
    }
    
}
    

