//
//  SwiftUIView.swift
//  SwiftPOC
//
//  Created by user on 06/02/26.
//

import SwiftUI
import Foundation
import Combine

class FoodService : ObservableObject{
    @Published var items : [FoodImageModel] = []
    @Published var filtered : [FoodImageModel] = []
    @Published var isLoading  : Bool = false
    @Published var searchText : String = ""
    private var cancellables = Set<AnyCancellable>()
    
    init(){
        $searchText
            .removeDuplicates()
            .debounce(for: .milliseconds(180), scheduler: DispatchQueue.main)
            .sink{[weak self] q in
                self?.filterItems(q)
            }
            .store(in: &cancellables)
    }
    
    func load(count:Int){
        for _ in 0..<count{
            fetch()
        }
    }
    
    private func fetch(){
        
        //let url = URL(string: "https://foodish-api.com/api/")!
        //let (data,_) = try await URLSession.shared.data(from: url)
        guard let url = URL(string: "https://foodish-api.com/api/")else{
            return
        }
        
        URLSession.shared.dataTask(with: url){data, _, _ in
            guard let data = data,
                  let result = try? JSONDecoder().decode(FoodImageModel.self,from:data) else {return}
            DispatchQueue.main.async{
                self.items.append(result)
            }
        }.resume()
    }
    
    func filterItems(_ queryText : String){
        let q = queryText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !q.isEmpty else {
            filtered = items
            return
        }
        let query = q.folding(options: .diacriticInsensitive, locale: .current).lowercased()
        filtered = items.filter{
            $0.name.lowercased().contains(query)
        }
        items = filtered
    }
    
    func resetSearch(){
        searchText = ""
        //load()
    }
}
