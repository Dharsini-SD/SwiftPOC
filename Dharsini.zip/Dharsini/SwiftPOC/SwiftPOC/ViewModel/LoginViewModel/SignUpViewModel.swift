//
//  SignUpViewModel.swift
//  SwiftPOC
//
//  Created by user on 22/01/26.
//

import Foundation


class SignUpViewModel : ObservableObject{
    @Published var userName : String = ""
    @Published var password : String = ""
    @Published var mail : String = ""
    @Published var phone : String = ""
    
    func signUp(){
        
    }
}
