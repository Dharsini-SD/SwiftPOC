//
//  FoodCardViewModel.swift
//  SwiftPOC
//
//  Created by user on 22/01/26.
//

import SwiftUI
import Foundation
import Combine

class FoodCardViewModel : ObservableObject{
    @Published var items : [FoodItemModel] = []
    @Published var filtered : [FoodItemModel] = []
    @Published var isLoading  : Bool = false
    //  private let categories = ["Burger","Pizza","Rice","Pasta","Briyani","Sweets","Dosa","Bread"]
    @Published var searchText : String = ""
    private var cancellables = Set<AnyCancellable>()
    
    init(){
        $searchText
            .removeDuplicates()
            .debounce(for: .milliseconds(180), scheduler: DispatchQueue.main)
            .sink{[weak self] q in
                self?.filterItems(q)
            }
            .store(in: &cancellables)
    }
    
    func loadInitial(){
        if items.isEmpty{ loadItems() }
    }
    
    func loadItems(){
        guard !isLoading else {return}
        isLoading = true
        
        Task{
            var newItems : [FoodItemModel] = []
            for _ in 0..<10{
                do{
                    let res = try await FoodAPIService.shared.fetchFoodImage()
                    newItems.append(FoodItemModel(
                        id: UUID(),
                        imageURL: res,
                        name: getNameFromURLString(urlString: res),
                        price: Double.random(in: 100...400),
                        rating: Double.random(in: 3...5))
                    )
                    
                }catch{
                    
                }
            }
            DispatchQueue.main.async{
                self.items.append(contentsOf:newItems)
                //self.filtered.append(contentsOf: newItems)
                self.isLoading = false
            }
            
                
            }
        }
    
    func filterItems(_ queryText : String){
        let q = queryText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !q.isEmpty else {
            filtered = items
            return
        }
        let query = q.folding(options: .diacriticInsensitive, locale: .current).lowercased()
        filtered = items.filter{
            $0.name.lowercased().contains(query)
        }
        items = filtered
    }
    
    func resetSearch(){
        searchText = ""
        loadItems()
    }
    
}
    
    
    private func getNameFromURLString(urlString:String) -> String{
        guard let url = URL(string: urlString) else {return "Food"}
        
        let parts = url.path.split(separator: "/").map(String.init)
        
        if parts.count >= 3{
            let res = parts[1]
            return res
        }
        
        return "Food"
    
     
}











