//
//  FoodDetailViewModel.swift
//  SwiftPOC
//
//  Created by user on 30/01/26.
//

import SwiftUI
import Foundation

@MainActor
class FoodDetailViewModel : ObservableObject{
    @Published var scheduledDate : Date = .now
    @Published var spiceLevel : Double = 4
    @Published var quantity : Int = 1
    @Published var notes : String = ""
}
