//
//  SwiftPOCTests.swift
//  SwiftPOCTests
//
//  Created by user on 22/01/26.
//

import Testing
@testable import SwiftPOC

struct SwiftPOCTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
