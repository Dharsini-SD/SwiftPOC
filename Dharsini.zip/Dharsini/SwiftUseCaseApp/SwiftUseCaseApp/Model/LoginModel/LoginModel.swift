//
//  LoginModel.swift
//  ClothingApp
//
//  Created by user on 07/01/26.
//

import Foundation

struct User : Codable{
    var userName : String = ""
    var password : String = ""
    var email : String = ""
    var phone : String = ""
}
