//
//  ClothingAppApp.swift
//  ClothingApp
//
//  Created by user on 07/01/26.
//

import SwiftUI

@main
struct SwiftUseCaseApp: App {
    var body: some Scene {
        WindowGroup {
            RootView()
        }
    }
}
