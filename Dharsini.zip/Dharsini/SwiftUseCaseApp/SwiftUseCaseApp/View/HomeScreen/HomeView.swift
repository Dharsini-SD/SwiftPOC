//
//  HomeView.swift
//  ClothingApp
//
//  Created by user on 08/01/26.
//

import SwiftUI

struct HomeView: View {
    var body: some View {
        TabView{
            Text("Hello")
                .tabItem{
                    Image(systemName: "cart.fill")
                }
            Text("hELLO")
                .tabItem{
                    Image(systemName: "house.fill")
                }
            Text("hELLO")
                .tabItem{
                    Image(systemName: "line.horizontal.3.decrease")
                }
            
            Text("Hello")
                .tabItem{
                    Image(systemName: "doc.text.fill")
                }
            
            Text("hello")
                .tabItem{
                    Image(systemName: "line.3.horizontal")
                }
            
        }
    }
}

#Preview {
    HomeView()
}
