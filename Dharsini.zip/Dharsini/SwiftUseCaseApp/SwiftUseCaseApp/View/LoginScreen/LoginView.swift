//
//  LoginView.swift
//  ClothingApp
//
//  Created by user on 07/01/26.
//

import SwiftUI

struct LoginView: View {
    @StateObject var loginVM : LoginViewModel = LoginViewModel()
    @AppStorage("isLoggedin") private var isLoggedIn : Bool = false
    @State private var isError : Bool = false
    var body: some View {
        VStack{
            Text("Login")
                .font(.largeTitle)
                .fontWeight(.bold)
                .foregroundStyle(Color.cyan)
                .padding(.bottom,40)
            
            TextField("Username", text: $loginVM.userName)
                .modifier(TextFieldModifier())
            
            SecureField("Password", text: $loginVM.password)
                .modifier(TextFieldModifier())
            
            
            if isError {
                Text("Invalid username/password")
                    .foregroundStyle(Color.red)
                    .font(.footnote)
                    .padding(.top)
            }
            
            Button(action:{
                if loginVM.userName.isEmpty || loginVM.password.isEmpty {
                    isError = true
                }else{
                    isLoggedIn = true
                }
            }){
                Text("Login").foregroundStyle(Color.white)
            }.frame(maxWidth: .infinity)
                .padding()
                .background(.cyan)
                .cornerRadius(15)
                .padding()
            
            Button("Forget Password?"){
                
            }.padding(.bottom)
            
            Button("Sign up"){
                
            }
            
        }
    }
}

struct TextFieldModifier : ViewModifier{
    func body(content: Content) -> some View {
        content
            .padding()
            .background(Color.gray.opacity(0.3))
            .cornerRadius(15)
            .padding(.horizontal)
    }
}

#Preview {
    LoginView()
}
