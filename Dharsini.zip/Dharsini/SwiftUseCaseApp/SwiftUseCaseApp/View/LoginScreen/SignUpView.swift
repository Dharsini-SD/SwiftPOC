//
//  SignUpView.swift
//  ClothingApp
//
//  Created by user on 07/01/26.
//

import SwiftUI

struct SignUpView: View {
   // @State var name : String = ""
   // @State var password : String = ""
   // @State var phoneNumber : String = ""
   // @State var mailAddress : String = ""
    
    @StateObject var signupVM : SignUpViewModel = SignUpViewModel()
    var body: some View {
        NavigationStack{
            VStack{
                TextField("Name", text: $signupVM.userName)
                    .modifier(TextFieldModifier())
                    .padding(.vertical,5)
                
                SecureField("Password",text:$signupVM.password)
                    .modifier(TextFieldModifier())
                    .padding(.vertical,5)
                
                TextField("MailAddress", text: $signupVM.mail)
                    .modifier(TextFieldModifier())
                    .padding(.vertical,5)
                
                TextField("PhoneNumber", text: $signupVM.phone)
                    .modifier(TextFieldModifier())
                    .padding(.vertical,5)
                    .keyboardType(.numberPad)
                
                Button("Sign Up"){
                    
                }.padding(.top)
                
                
            }
        }.navigationTitle("SignUp")
    }
}

#Preview {
    SignUpView()
}
