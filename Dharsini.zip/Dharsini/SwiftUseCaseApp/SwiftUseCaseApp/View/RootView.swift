//
//  RootView.swift
//  ClothingApp
//
//  Created by user on 08/01/26.
//

import Foundation
import SwiftUI

struct RootView : View {
    @AppStorage("isLoggedin") private var isLoggedIn : Bool = false
    var body: some View {
        NavigationStack{
            if isLoggedIn{
                HomeView()
            }else{
                LoginView()
            }
        }
        
    }
}
