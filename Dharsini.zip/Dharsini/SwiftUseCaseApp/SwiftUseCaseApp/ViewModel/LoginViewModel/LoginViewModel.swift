//
//  LoginViewModel.swift
//  ClothingApp
//
//  Created by user on 07/01/26.
//

import Foundation
import SwiftUI

class LoginViewModel : ObservableObject{
    @Published var userName : String = ""
    @Published var password : String = ""
    
    func login(){
        
    }
}
