//
//  ShopView.swift
//  ClothingApp
//
//  Created by user on 09/01/26.
//

import SwiftUI

struct ShopView: View {
    @State private var searchText : String = ""
    var body: some View {
        VStack{
            
        }
    }
}

#Preview {
    ShopView()
}

